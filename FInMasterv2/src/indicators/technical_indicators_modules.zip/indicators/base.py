class IndicatorCalculationError(Exception):
    """Custom exception for errors during technical indicator calculation."""
    pass
